
class User:
    def __init__(self, user_id, salt, hased_pwd, prime):
        self.user_id = user_id
        self.salt = salt
        self.hased_pwd = hased_pwd
        self.prime = prime
    def __str__(self):
        return self.user_id+self.salt+self.hased_pwd+self.prime

def get_user_details():
    try:
        lines = tuple(open("pwd_file1", 'r'))
    except IOError as error:
        print("Password file not found!")
        return {}
        #lines = tuple(open("pwd_file1", 'r'))
    user_cache = {}#key as user_id and value as User object
    for each in lines:
        uDetail = each.split(":")
        user = User(uDetail[0], uDetail[1], uDetail[2], uDetail[3])
        user_cache[uDetail[0]] = user
    return user_cache

#Returns True if user_id exist, False otherwise
def is_user_exist(user_id):
    user_details = get_user_details()
    return user_id in user_details

def register_user(user):
    f = open("pwd_file", "a")
    f.write(user.user_id+":"+user.salt+":"+user.hased_pwd+":"+user.prime+"\n")

#register_user(User("username2","mysalt","myhashedpwd","myprime"))
#print(get_user_details())