import socket
from Classes import Hdr, Message

class ServerManager:
    
    def __init__(self, port=9009):
        self.port = port

    def getConnection(self):
        ''' Returns a TCP/IP connection object '''
        connection = socket.socket()
        connection.bind(('', self.port)) #Binded connection to machine IP and mentioned port
        connection.listen(5) #Put max 5 clients waiting for connection, 6th gets refused
        return connection
