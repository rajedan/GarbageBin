from random import randrange, getrandbits
import time as time

def is_prime(n, k=128):
    """ Test if a number is prime
        Args:
            n -- int -- the number to test
            k -- int -- the number of tests to do
        return True if n is prime
    """
    if n == 2 or n == 3:
        return True
    if n <= 1 or n % 2 == 0:
        return False
    # find r and s
    s = 0
    r = n - 1
    while r & 1 == 0:
        s += 1
        r //= 2
    # do k tests
    for _ in range(k):
        a = randrange(2, n - 1)
        x = pow(a, r, n)
        if x != 1 and x != n - 1:
            j = 1
            while j < s and x != n - 1:
                x = pow(x, 2, n)
                if x == 1:
                    return False
                j += 1
            if x != n - 1:
                return False

    return True

def generate_prime_candidate(length):
    """ Generate an odd integer randomly
        Args:
            length -- int -- the length of the number to generate, in bits
        return a integer
    """
    # generate random bits
    p = getrandbits(length)
    # apply a mask to set MSB and LSB to 1
    p |= (1 << length - 1) | 1

    return p

def generate_prime_number(length=12):
    """ Generate a prime

        Args:
            length -- int -- length of the prime to generate, in          bits

        return a prime
    """
    p = 4
    # keep generating while the primality test fail
    while not is_prime(p, 128):
        p = generate_prime_candidate(length)
    return p

def get_random_number(upper_limit, lower_limit=2):
    return randrange(lower_limit, upper_limit)

def power_and_mod(x, y, p) : 
    """
    Calculates x^y mod p for large numbers
    """
    res = 1     # Initialize result 
  
    x = x % p
  
    while (y > 0) : 
          
        # If y is odd, multiply 
        # x with result 
        if ((y & 1) == 1) : 
            res = (res * x) % p 
  
        # y must be even now 
        y = y >> 1      # y = y/2 
        x = (x * x) % p 
          
    return res

def get_KR_KU_Q(q, alpha):
    """
    q : Large Prime Number
    alpha : Primitive root of q
    It gives you a set of private and public key
    """
    X = get_random_number(q) #Private key
    Y = power_and_mod(alpha, X, q)#alpha^X mod q #Public key
    return (X, Y, q)

def gcd(a,b):
    while a != b:
        if a > b:
            a = a - b
        else:
            b = b - a
    return a

def primitive_root(modulo):
    required_set = set(num for num in range (1, modulo) if gcd(num, modulo) == 1)
    for g in range(1, modulo):
        actual_set = set(pow(g, powers) % modulo for powers in range (1, modulo))
        if required_set == actual_set:
            return g

#This method gives you (X, Y, Q) where X is private key of the user, 
#Y is public key of the user and Q is prime number used to create these
#Please note that this prime number should be shared between client and server before hand
def get_user_a_pr_pub_keys(q=None):
    """(X,Y,Q)"""
    if q is None:
        q = generate_prime_number(13)#Please do not try more then 13 bits of prime numer, your machine will shutdown
    alpha = primitive_root(q)
    keys = get_KR_KU_Q(q, alpha)
    return keys

def get_user_b_pr_pub_keys(q=None):
    if q is None:
        q = generate_prime_number(13)#Please do not try more then 13 bits of prime numer, your machine will shutdown
    alpha = primitive_root(q)
    keys = get_KR_KU_Q(q, alpha)
    return keys

def get_k_for_user_a(XA, YB, q):
    return power_and_mod(YB, XA, q)

keysA = get_user_a_pr_pub_keys()
keysB = get_user_b_pr_pub_keys(keysA[2])

k1 = get_k_for_user_a(keysA[0], keysB[1], keysA[2])
k2 = get_k_for_user_a(keysB[0], keysA[1], keysB[2])
print ("k1:", k1, " k2:", k2)