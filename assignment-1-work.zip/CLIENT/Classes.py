class Hdr:
    '''
    A class represeting Header of a message with fields :
    opcode, s_addr and d_addr
    Possible opcodes : 10, 20, 30, 40, 50, 60
    '''
    def __init__(self, opcode, s_addr, d_addr):
        self.opcode = opcode    #opcode for a message
        self.s_addr = s_addr    #source address
        self.d_addr = d_addr    #destination address

class Message:
    '''
    A class which represents a Message which can be 
    send among client and server
    '''

    def __init__(self):
        self.hdr = None     #Contains Hdr object representing Header of message
        self.buf = None     #Buffer : Contains all or some part of the plain text message, max buffer size is 1024bytes
        self.id = None      #Contains ID of the connecting User, max id size is 80bytes
        self.password = None#Contains Entered Password of the connecting User
        self.status = None  #statuc : SUCCESSFUL or UNSUCCESSFUL for successful or unsuccessful result in LOGINREPLY and AUTHREPLY messages
        self.file = None    #The file which will be transmitted by the server to the client, max file size is 80bytes
        self.q = 3          #A prime
        self.dummy = 0      #dummy variable, used when necessary

if __name__ == "__main__":
    h = Hdr(10, "127.0.0.1", "127.0.0.2")
    #h.newelem = "myname"
    print h.opcode, h.d_addr, h.s_addr