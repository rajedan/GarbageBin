import socket
from Classes import Hdr
from Classes import Message

class ClientManager:
    
    def __init__(self, ip='127.0.0.1', port=9009):
        self.ip = ip
        self.port = port

    def getConnection(self):
        ''' Returns a TCP/IP socket connection object '''
        s = socket.socket()
        s.connect((self.ip, self.port))
        return s

    def send(self, s=None, plaintext=None):
        pass

    def recv(self, s=None):
        plaintext = s.recv(1024) #Change the buffer size based on Message Header
        return plaintext